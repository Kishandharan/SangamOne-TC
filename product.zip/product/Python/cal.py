try:
	print(eval(input(">")))
except:
	print("Oops! Something went wrong, Please try again.")